'use client';
import { useEffect, useState } from 'react';
import { useLang } from '@/context/LangContext';

export default function Loader() {
  const { t } = useLang();
  const [hidden, setHidden] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setHidden(true), 1200);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div id="loader" className={hidden ? 'hidden' : ''}>
      <div className="loader-logo-wrap">
        <div className="brand-logo-vector" style={{ width: 80, height: 80 }}>
          <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M30 75L46 30H54L70 75M34 63H66" stroke="#c9a84c" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M42 42C42 42 48 36 58 42C68 48 62 58 52 56C42 54 44 68 56 68C68 68 72 62 72 62" stroke="#e8c97a" strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      </div>
      <div className="loader-text">{t('أحمد سعد — وكالة إبداعية', 'Ahmed Saad — Creative Agency')}</div>
      <div className="loader-line"></div>
    </div>
  );
}
