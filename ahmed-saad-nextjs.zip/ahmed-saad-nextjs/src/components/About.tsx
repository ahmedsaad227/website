'use client';
import { useLang } from '@/context/LangContext';

export default function About() {
  const { t, dir } = useLang();

  const skills = [
    'Adobe Illustrator', 'Adobe Photoshop', 'Adobe InDesign',
    t('تصميم مطبوعات', 'Print Design'),
    t('هوية بصرية', 'Brand Identity'),
    t('سوشيال ميديا', 'Social Media'),
    t('بروشورات فاخرة', 'Luxury Brochures'),
    t('كتالوجات', 'Catalogues'),
  ];

  const cards = [
    { icon: '🏆', num: '+150', label: t('مشروع مُنجَز', 'Completed Projects') },
    { icon: '⭐', num: '+80', label: t('عميل راضٍ', 'Satisfied Clients') },
    { icon: '🌍', num: '5+', label: t('دول خدمتها', 'Countries Served') },
    { icon: '🎯', num: '100%', label: t('التزام بالمواعيد', 'On-Time Delivery') },
  ];

  return (
    <section id="about" dir={dir}>
      <div className="container">
        <div className="about-grid">
          <div className="about-text reveal">
            <div className="section-eyebrow">{t('من أنا', 'About Me')}</div>
            <div className="gold-divider"></div>
            <h2>
              {t(
                <><span>مصمم جرافيك</span><br />متخصص في <span className="gold-text">المطبوعات الفاخرة</span></>,
                <><span>Graphic Designer</span><br />Specialized in <span className="gold-text">Premium Print</span></>
              ) as React.ReactNode}
            </h2>
            <p className="about-body">
              {t(
                'أحمد سعد — مصمم جرافيك متخصص في إنتاج مطبوعات تجارية فاخرة، تصاميم سوشيال ميديا، وهويات بصرية متكاملة. أعمل مع الشركات والعلامات التجارية الكبرى في السوق السعودي والعربي لتحويل رؤيتهم إلى قطع تصميمية استثنائية تُحدث أثراً حقيقياً في السوق.',
                'Ahmed Saad — graphic designer specializing in premium commercial print, social media designs, and complete visual identities. I work with leading brands across Saudi Arabia and the Arab world to transform their vision into exceptional design pieces that make a real market impact.'
              )}
            </p>
            <div className="about-skills">
              {skills.map((s, i) => <span key={i} className="skill-tag">{s}</span>)}
            </div>
          </div>
          <div className="about-visual reveal">
            {cards.map((c, i) => (
              <div key={i} className="about-card">
                <span className="about-card-icon">{c.icon}</span>
                <div>
                  <div className="about-card-num">{c.num}</div>
                  <div className="about-card-label">{c.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
