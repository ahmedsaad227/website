'use client';
import { useState } from 'react';
import { useLang } from '@/context/LangContext';

type IdentityType = 'luxury' | 'tech' | 'youth';

const identities = {
  luxury: {
    label: { ar: '🏛 فاخر', en: '🏛 Luxury' },
    text: 'Ahmed Saad Studio',
    color: '#e8c97a',
    font: "'Playfair Display', 'Cairo', serif",
    explain: {
      ar: 'تعتمد بروشورات ومطبوعات الشركات الكبرى والفاخرة على تباين عالي جداً واستخدام درجات داكنة ومتزنة مع نصوص واضحة توحي بالهيبة العريقة والثقة المطلقة للعملاء.',
      en: 'Luxury brochures rely on extreme contrast, deep balanced tones, and clear typography that convey prestige and absolute client trust.',
    },
    palette: ['#050b1a', '#020409', '#c9a84c', '#f8f6f2'],
  },
  tech: {
    label: { ar: '⚡ تقني', en: '⚡ Tech' },
    text: '⚡ SAAD.DIGITAL',
    color: '#00f2fe',
    font: "'Tajawal', sans-serif",
    explain: {
      ar: 'التصاميم والمطبوعات الرقمية التقنية تركز على البساطة المتناهية (Minimalism) والخطوط الهندسية المستقيمة، وتعتمد في حملات السوشيال ميديا على تدرجات النيون الحية لإعطاء طابع مستقبلي ذكي.',
      en: 'Tech designs focus on extreme minimalism and geometric lines. Social media campaigns leverage vivid neon gradients for a smart, futuristic feel.',
    },
    palette: ['#010a15', '#00f2fe', '#4facfe', '#ffffff'],
  },
  youth: {
    label: { ar: '🔥 شبابي', en: '🔥 Youth' },
    text: '🔥 أحمد سعد . جمدان',
    color: '#ff416c',
    font: "'Cairo', sans-serif",
    explain: {
      ar: 'الحملات الإعلانية الشبابية وحملات السوشيال ميديا الحيوية تعتمد على كسر القواعد الكلاسيكية؛ خطوط مائلة حادة، وألوان متصادمة قوية لشد انتباه جيل الشباب وصنع ضجة إعلانية.',
      en: 'Youth campaigns break classic rules — bold diagonal lines and clashing colors grab the young generation\'s attention and create a viral effect.',
    },
    palette: ['#111111', '#ff416c', '#ff4b2b', '#ffcc00'],
  },
};

export default function Playground() {
  const { t, lang, dir } = useLang();
  const [active, setActive] = useState<IdentityType>('luxury');
  const [fading, setFading] = useState(false);

  const switchIdentity = (type: IdentityType) => {
    setFading(true);
    setTimeout(() => { setActive(type); setFading(false); }, 300);
  };

  const id = identities[active];

  return (
    <section id="playground" dir={dir}>
      <div className="container">
        <div className="reveal" style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div className="section-eyebrow">{t('مختبر التصميم', 'Design Lab')}</div>
          <div className="gold-divider" style={{ margin: '0 auto 1rem' }}></div>
          <h2 className="section-title">
            {t('جرّب ', 'Experience ')}
            <span className="gold-text">{t('أسلوبك المفضل', 'Your Preferred Style')}</span>
          </h2>
        </div>
        <div className="playground-wrap reveal">
          <div className="pg-btns">
            {(Object.entries(identities) as [IdentityType, typeof id][]).map(([key, val]) => (
              <button
                key={key}
                className={`pg-btn${active === key ? ' active' : ''}`}
                onClick={() => switchIdentity(key)}
              >
                {lang === 'ar' ? val.label.ar : val.label.en}
              </button>
            ))}
          </div>
          <div className="pg-demo-area">
            <div
              className="pg-brand-text"
              style={{ color: id.color, fontFamily: id.font, opacity: fading ? 0 : 1, transition: 'opacity 0.3s' }}
            >
              {id.text}
            </div>
            <p className="pg-explain" style={{ opacity: fading ? 0 : 1, transition: 'opacity 0.3s' }}>
              {lang === 'ar' ? id.explain.ar : id.explain.en}
            </p>
            <div className="pg-palette" style={{ opacity: fading ? 0 : 1, transition: 'opacity 0.3s' }}>
              {id.palette.map((c, i) => (
                <div key={i} className="pg-color-swatch" style={{ background: c }}></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
