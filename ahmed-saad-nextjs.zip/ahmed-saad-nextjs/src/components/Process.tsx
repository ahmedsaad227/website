'use client';
import { useLang } from '@/context/LangContext';

export default function Process() {
  const { t, dir } = useLang();

  const steps = [
    {
      num: '01',
      icon: '💬',
      title: t('الاستشارة المجانية', 'Free Consultation'),
      desc: t(
        'نبدأ بنقاش مفصّل لفهم احتياجاتك، هويتك البصرية، والجمهور المستهدف لضمان تقديم أفضل النتائج.',
        'We start with a detailed discussion to understand your needs, visual identity, and target audience to ensure the best results.'
      ),
    },
    {
      num: '02',
      icon: '✏️',
      title: t('العرض الأولي والموافقة', 'Initial Draft & Approval'),
      desc: t(
        'أقدم لك أول مسودة تصميمية خلال 48 ساعة، مع مرونة كاملة في التعديل حتى الوصول إلى رضاك التام.',
        'I deliver the first design draft within 48 hours, with full flexibility to revise until you\'re completely satisfied.'
      ),
    },
    {
      num: '03',
      icon: '🔄',
      title: t('مراجعة وتطوير', 'Review & Refinement'),
      desc: t(
        'جولات تعديل غير محدودة على الباقات المتقدمة، لأن التفاصيل الدقيقة هي ما يُحدث الفرق الحقيقي.',
        'Unlimited revision rounds on advanced packages, because it\'s the fine details that make the real difference.'
      ),
    },
    {
      num: '04',
      icon: '📦',
      title: t('التسليم والملفات النهائية', 'Delivery & Final Files'),
      desc: t(
        'تسليم المشروع بجميع الملفات المطلوبة جاهزة للطباعة والنشر الرقمي بأعلى جودة وأدق المواصفات.',
        'Project delivered with all required files, print-ready and optimized for digital publishing at the highest quality.'
      ),
    },
  ];

  return (
    <section id="process" dir={dir}>
      <div className="container">
        <div className="reveal" style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div className="section-eyebrow">{t('طريقة العمل', 'How I Work')}</div>
          <div className="gold-divider" style={{ margin: '0 auto 1rem' }}></div>
          <h2 className="section-title">
            {t('رحلة ', 'The ')}
            <span className="gold-text">{t('العمل معي', 'Work Journey')}</span>
          </h2>
        </div>
        <div className="process-steps">
          {steps.map((s, i) => (
            <div key={i} className="process-step reveal">
              <div className="step-num">{s.num}</div>
              <div className="step-icon">{s.icon}</div>
              <div className="step-title">{s.title}</div>
              <p className="step-desc">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
