'use client';
import { useEffect, useState } from 'react';
import { useLang } from '@/context/LangContext';

export default function Navbar() {
  const { lang, toggleLang, t, dir } = useLang();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <nav id="navbar" className={scrolled ? 'scrolled' : ''} dir={dir}>
      <div className="nav-brand-area">
        <div className="brand-logo-vector" style={{ width: 44, height: 44 }}>
          <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M30 75L46 30H54L70 75M34 63H66" stroke="#c9a84c" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M42 42C42 42 48 36 58 42C68 48 62 58 52 56C42 54 44 68 56 68C68 68 72 62 72 62" stroke="#e8c97a" strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <span className="nav-logo-text">
          {t('أحمد سعد', 'Ahmed Saad')}
        </span>
      </div>

      <ul className={`nav-links${menuOpen ? ' active' : ''}`} id="navLinks">
        <li><a href="#about" onClick={closeMenu}>{t('من أنا', 'About')}</a></li>
        <li><a href="#playground" onClick={closeMenu}>{t('مختبر التصميم', 'Design Lab')}</a></li>
        <li><a href="#process" onClick={closeMenu}>{t('رحلة العمل', 'Process')}</a></li>
        <li><a href="#pricing" onClick={closeMenu}>{t('الباقات والعروض', 'Pricing')}</a></li>
        <li><a href="https://www.behance.net/medosaad227" target="_blank" rel="noreferrer" onClick={closeMenu}>{t('الأعمال', 'Portfolio')}</a></li>
        <li>
          <a href="https://wa.me/201061147992" className="nav-cta" target="_blank" rel="noreferrer" onClick={closeMenu}>
            {t('ابدأ مشروعك', 'Start Your Project')}
          </a>
        </li>
      </ul>

      {/* ─── LANGUAGE TOGGLE ─── */}
      <button
        className="lang-toggle"
        onClick={toggleLang}
        aria-label="Toggle language"
        title={lang === 'ar' ? 'Switch to English' : 'التبديل إلى العربية'}
      >
        <span className={`lang-option${lang === 'ar' ? ' active' : ''}`}>AR</span>
        <span className={`lang-option${lang === 'en' ? ' active' : ''}`}>EN</span>
      </button>

      <div
        className="hamburger"
        id="hamburger"
        onClick={() => setMenuOpen((v) => !v)}
        aria-label="Toggle menu"
      >
        <span></span>
        <span></span>
        <span></span>
      </div>
    </nav>
  );
}
