'use client';
import { useLang } from '@/context/LangContext';

export default function Portfolio() {
  const { t, dir } = useLang();

  const items = [
    { emoji: '🏢', title: 'Al Hussein Real Estate', sub: t('بروشور عقاري فاخر متعدد الصفحات', 'Multi-page luxury real estate brochure') },
    { emoji: '🍖', title: 'Shawarma Take — Makkah', sub: t('حملة سوشيال ميديا + هوية بصرية', 'Social media campaign + brand identity') },
    { emoji: '📋', title: "Alaa Arfa Group", sub: t('كتالوج تجاري للتوريدات العمومية', 'Commercial catalogue for general supplies') },
    { emoji: '🏠', title: 'Right Home', sub: t('إنفوجرافيك تفصيلي للوحدات السكنية', 'Detailed residential unit infographic') },
    { emoji: '✨', title: t('مشاريع متعددة', 'Multiple Projects'), sub: t('هويات بصرية لعملاء سعوديين', 'Visual identities for Saudi clients') },
    { emoji: '📱', title: t('حملات رقمية', 'Digital Campaigns'), sub: t('تصاميم إعلانية لمنصات التواصل', 'Ad creatives for social platforms') },
  ];

  return (
    <section id="portfolio" dir={dir}>
      <div className="container">
        <div className="reveal" style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div className="section-eyebrow">{t('معرض الأعمال', 'Portfolio')}</div>
          <div className="gold-divider" style={{ margin: '0 auto 1rem' }}></div>
          <h2 className="section-title">
            {t('أعمال ', 'Work that ')}
            <span className="gold-text">{t('تتحدث عن نفسها', 'Speaks for Itself')}</span>
          </h2>
        </div>
        <div className="portfolio-grid reveal">
          {items.map((item, i) => (
            <div key={i} className="portfolio-item">
              <div className="portfolio-bh-mockup">{item.emoji}</div>
              <div className="portfolio-bh-overlay">
                <h4>{item.title}</h4>
                <p>{item.sub}</p>
                <a href="https://www.behance.net/medosaad227" target="_blank" rel="noreferrer" className="view-project-btn">
                  {t('عرض على Behance ↗', 'View on Behance ↗')}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
