'use client';
import { useEffect } from 'react';

export default function ScrollReveal() {
  useEffect(() => {
    const reveal = () => {
      const elements = document.querySelectorAll('.reveal');
      elements.forEach((el) => {
        const top = el.getBoundingClientRect().top;
        if (top < window.innerHeight - 100) el.classList.add('visible');
      });
    };
    window.addEventListener('scroll', reveal);
    reveal();
    return () => window.removeEventListener('scroll', reveal);
  }, []);

  return null;
}
