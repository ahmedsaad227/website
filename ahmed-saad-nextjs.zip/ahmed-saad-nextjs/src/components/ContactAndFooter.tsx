'use client';
import { useLang } from '@/context/LangContext';

export default function ContactAndFooter() {
  const { t, dir } = useLang();

  return (
    <>
      <section id="contact" dir={dir}>
        <div className="contact-inner container reveal">
          <div className="section-eyebrow" style={{ justifyContent: 'center' }}>{t('تواصل معي', 'Get in Touch')}</div>
          <h2 className="contact-headline">
            {t(
              <>هل أنت مستعد لنقل تصاميمك<br /><span className="gold-text">إلى آفاق أعلى؟</span></>,
              <>Ready to take your designs<br /><span className="gold-text">to the next level?</span></>
            ) as React.ReactNode}
          </h2>
          <p className="contact-sub">
            {t(
              'دعنا نناقش حملتك القادمة ونصنع بروشورات وتصاميم سوشيال ميديا مشرفة تدعم انتشارك وثقة عملائك في السوق.',
              "Let's discuss your next campaign and create outstanding brochures and social media designs that boost your reach and client trust in the market."
            )}
          </p>
          <div className="contact-socials">
            <a href="https://wa.me/201061147992" className="social-link" target="_blank" rel="noreferrer">
              <span>{t('واتساب ومكالمات', 'WhatsApp & Calls')}</span>
            </a>
            <a href="mailto:medosaad227@gmail.com" className="social-link" target="_blank" rel="noreferrer">
              <span>{t('البريد الإلكتروني', 'Email')}</span>
            </a>
          </div>
        </div>
      </section>

      <footer dir={dir}>
        <div className="container footer-inner">
          <div className="footer-logo-area">
            <div className="brand-logo-vector" style={{ width: 24, height: 24 }}>
              <svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M30 75L46 30H54L70 75M34 63H66" stroke="#c9a84c" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M42 42C42 42 48 36 58 42C68 48 62 58 52 56C42 54 44 68 56 68C68 68 72 62 72 62" stroke="#e8c97a" strokeWidth="5.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <div className="footer-logo-text">
              {t('أحمد سعد | وكالة إبداعية متكاملة', 'Ahmed Saad | Full-Service Creative Agency')}
            </div>
          </div>
          <div className="footer-copy">
            {t('© ٢٠٢٦ جميع الحقوق محفوظة — أحمد سعد', '© 2026 All rights reserved — Ahmed Saad')}
          </div>
        </div>
      </footer>
    </>
  );
}
