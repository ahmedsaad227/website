'use client';
import { useEffect, useRef } from 'react';
import { useLang } from '@/context/LangContext';

export default function Hero() {
  const { t, dir } = useLang();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => { canvas.width = canvas.offsetWidth; canvas.height = canvas.offsetHeight; };
    window.addEventListener('resize', resize);
    resize();

    class Particle {
      x: number; y: number; size: number;
      speedX: number; speedY: number; alpha: number;
      constructor() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.size = Math.random() * 2 + 0.5;
        this.speedX = Math.random() * 0.4 - 0.2;
        this.speedY = Math.random() * -0.5 - 0.1;
        this.alpha = Math.random() * 0.5 + 0.2;
      }
      update() {
        this.x += this.speedX; this.y += this.speedY;
        if (this.y < 0) { this.y = canvas.height; this.x = Math.random() * canvas.width; }
      }
      draw() {
        ctx!.save(); ctx!.globalAlpha = this.alpha; ctx!.beginPath();
        ctx!.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx!.fillStyle = '#c9a84c'; ctx!.shadowBlur = 8; ctx!.shadowColor = '#e8c97a';
        ctx!.fill(); ctx!.restore();
      }
    }

    const particles: Particle[] = Array.from({ length: 60 }, () => new Particle());
    let raf: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach(p => { p.update(); p.draw(); });
      raf = requestAnimationFrame(animate);
    };
    animate();
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', resize); };
  }, []);

  return (
    <section id="hero" dir={dir}>
      <div className="hero-bg"></div>
      <canvas id="gold-canvas" ref={canvasRef}></canvas>
      <div className="hero-content">
        <div className="hero-text">
          <div className="hero-eyebrow">Creative Design Agency</div>
          <h1 className="hero-headline">
            {t(
              <><span style={{display:'block'}}>نصنع تصاميم ومطبوعات</span><span>تخطف الأنظار وتبيع</span></>,
              <><span style={{display:'block'}}>We craft designs &amp; prints</span><span>that captivate and sell</span></>
            ) as React.ReactNode}
          </h1>
          <p className="hero-sub">
            {t(
              'تصميم حملات سوشيال ميديا إبداعية، بروشورات، ومطبوعات تجارية بأسلوب فاخر يمنح براندك التميز المطلق في السوق العربي والسعودي.',
              'Creative social media campaigns, brochures, and premium commercial print — designed to give your brand unmatched distinction in the Arab market.'
            )}
          </p>
          <div className="hero-buttons">
            <a href="https://www.behance.net/medosaad227" className="btn-primary" target="_blank" rel="noreferrer">
              <span>{t('مشاهدة الأعمال', 'View Portfolio')}</span>
            </a>
            <a href="https://wa.me/201061147992" className="btn-secondary" target="_blank" rel="noreferrer">
              {t('تواصل الآن ←', 'Contact Now →')}
            </a>
          </div>
          <div className="hero-stats">
            <div className="stat-item">
              <div className="stat-number">+150</div>
              <div className="stat-label">{t('مشروع مُنجَز', 'Projects Done')}</div>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-item">
              <div className="stat-number">+80</div>
              <div className="stat-label">{t('عميل راضٍ', 'Happy Clients')}</div>
            </div>
            <div className="stat-divider"></div>
            <div className="stat-item">
              <div className="stat-number">5+</div>
              <div className="stat-label">{t('سنوات خبرة', 'Years Experience')}</div>
            </div>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-showcase-card">
            <div className="showcase-label">{t('أبرز خدماتي', 'My Core Services')}</div>
            <div className="showcase-items">
              {[
                { icon: '🎨', title: t('تصميم بروشورات', 'Brochure Design'), sub: t('مطبوعات جاهزة للطباعة', 'Print-ready files') },
                { icon: '📱', title: t('سوشيال ميديا', 'Social Media'), sub: t('تصاميم إعلانية مؤثرة', 'High-impact ad creatives') },
                { icon: '🏢', title: t('هوية بصرية', 'Brand Identity'), sub: t('لوجو وتصميم متكامل', 'Logo & full brand system') },
                { icon: '📄', title: t('كتالوجات تجارية', 'Commercial Catalogues'), sub: t('تصميم احترافي للمطابع', 'Press-ready professional design') },
              ].map((item, i) => (
                <div key={i} className="showcase-item">
                  <span className="showcase-icon">{item.icon}</span>
                  <div className="showcase-item-text">
                    <div className="showcase-item-title">{item.title}</div>
                    <div className="showcase-item-sub">{item.sub}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
