'use client';
import { useLang } from '@/context/LangContext';

export default function Testimonials() {
  const { t, dir } = useLang();

  const testimonials = [
    {
      text: t(
        '"أحمد قدم لنا بروشور ومطبوعات تجارية في غاية الفخامة لعقارات الحسين، دقة متناهية في توزيع العناصر واختيار الألوان المتناسقة مع هويتنا الاستثمارية."',
        '"Ahmed delivered exceptionally luxurious brochures and commercial prints for Al Hussein Real Estate — meticulous element distribution and perfectly aligned colors matching our investment identity."'
      ),
      avatar: t('ع', 'H'),
      name: t('إدارة عقارات الحسين', 'Al Hussein Real Estate Management'),
      role: t('المملكة العربية السعودية', 'Saudi Arabia'),
    },
    {
      text: t(
        '"تصاميم السوشيال ميديا والإعلانات التي صممها أحمد لشاورما تيك بمكة ساهمت بشكل مباشر في رفع مبيعاتنا، وجعلت حساباتنا تبدو بمنتهى الاحترافية والعصرية."',
        '"Ahmed\'s social media designs and ads for Shawarma Take in Makkah directly boosted our sales and made our accounts look entirely professional and modern."'
      ),
      avatar: t('ش', 'S'),
      name: t('إدارة شاورما تيك', 'Shawarma Take Management'),
      role: t('مكة المكرمة', 'Makkah'),
    },
    {
      text: t(
        '"تسلمنا الكتالوج التجاري والمطبوعات الرسمية لمجموعتنا، والتصميم كان جاهزاً ومقاداً للمطبعة بدون أي مشاكل في الألوان أو الأبعاد الدقيقة. مصمم ممتاز ومحترف."',
        '"We received the commercial catalogue and official prints for our group. The design was press-ready with zero color or dimension issues. An excellent, professional designer."'
      ),
      avatar: t('أ', 'A'),
      name: t('مجموعة علاء عرفة', 'Alaa Arfa Group'),
      role: t('للتوريدات العمومية', 'General Supplies'),
    },
  ];

  return (
    <section id="testimonials" dir={dir}>
      <div className="container">
        <div className="reveal" style={{ textAlign: 'center', marginBottom: '4rem' }}>
          <div className="section-eyebrow">{t('آراء العملاء', 'Client Reviews')}</div>
          <div className="gold-divider" style={{ margin: '0 auto 1rem' }}></div>
          <h2 className="section-title">
            {t('شركاء ', 'Success ')}
            <span className="gold-text">{t('النجاح', 'Partners')}</span>
            {t(' يقولون', ' Say')}
          </h2>
        </div>
        <div className="testimonials-track reveal">
          {testimonials.map((item, i) => (
            <div key={i} className="testi-card">
              <div className="testi-quote">"</div>
              <p className="testi-text">{item.text}</p>
              <div className="testi-author">
                <div className="testi-avatar">{item.avatar}</div>
                <div>
                  <div className="testi-name">{item.name}</div>
                  <div className="testi-role">{item.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
