'use client';
import { useLang } from '@/context/LangContext';

export default function Pricing() {
  const { t, dir } = useLang();

  const plans = [
    {
      name: t('الباقة الأساسية', 'Starter Package'),
      badge: null,
      price: '199',
      currency: t('ر.س', 'SAR'),
      period: t('/ مشروع', '/ project'),
      features: [
        t('تصميم واحد احترافي', '1 professional design'),
        t('ملفات جاهزة للطباعة', 'Print-ready files'),
        t('تعديلان مجانيان', '2 free revisions'),
        t('تسليم خلال 48 ساعة', '48-hour delivery'),
      ],
      cta: t('ابدأ الآن', 'Get Started'),
      ctaClass: 'outline',
      featured: false,
    },
    {
      name: t('الباقة المتقدمة', 'Advanced Package'),
      badge: t('الأكثر طلباً', 'Most Popular'),
      price: '499',
      currency: t('ر.س', 'SAR'),
      period: t('/ مشروع', '/ project'),
      features: [
        t('حتى 5 تصاميم احترافية', 'Up to 5 professional designs'),
        t('بروشور / كتالوج كامل', 'Full brochure / catalogue'),
        t('تعديلات غير محدودة', 'Unlimited revisions'),
        t('ملفات للطباعة والسوشيال', 'Print & social media files'),
        t('أولوية في التسليم', 'Priority delivery'),
      ],
      cta: t('اختر الباقة', 'Choose Package'),
      ctaClass: '',
      featured: true,
    },
    {
      name: t('باقة الهوية الكاملة', 'Full Brand Package'),
      badge: null,
      price: '1,199',
      currency: t('ر.س', 'SAR'),
      period: t('/ مشروع', '/ project'),
      features: [
        t('هوية بصرية كاملة', 'Complete visual identity'),
        t('لوجو + كتالوج + بروشور', 'Logo + catalogue + brochure'),
        t('تصاميم سوشيال ميديا', 'Social media designs (10 posts)'),
        t('ملفات مصدرية كاملة', 'Full source files'),
        t('دعم مستمر شهر كامل', '1 month ongoing support'),
      ],
      cta: t('تواصل معي', 'Contact Me'),
      ctaClass: 'outline',
      featured: false,
    },
  ];

  return (
    <section id="pricing" dir={dir}>
      <div className="container">
        <div className="reveal" style={{ textAlign: 'center', marginBottom: '3rem' }}>
          <div className="section-eyebrow">{t('خطط الاستثمار الإعلاني', 'Investment Plans')}</div>
          <div className="gold-divider" style={{ margin: '0 auto 1rem' }}></div>
          <h2 className="section-title">
            {t('باقات التصميم ', 'Design Packages ')}
            <span className="gold-text">{t('بعروض خصم 75% لفترة محدودة', '— 75% off for limited time')}</span>
          </h2>
        </div>
        <div className="pricing-grid reveal">
          {plans.map((plan, i) => (
            <div key={i} className={`pricing-card${plan.featured ? ' featured' : ''}`}>
              {plan.badge && <div className="pricing-badge">{plan.badge}</div>}
              <div className="pricing-name">{plan.name}</div>
              <div className="pricing-price">
                <span className="pricing-currency">{plan.currency}</span>
                {plan.price}
              </div>
              <div className="pricing-period">{plan.period}</div>
              <ul className="pricing-features">
                {plan.features.map((f, j) => <li key={j}>{f}</li>)}
              </ul>
              <a
                href="https://wa.me/201061147992"
                target="_blank"
                rel="noreferrer"
                className={`pricing-cta${plan.ctaClass ? ' ' + plan.ctaClass : ''}`}
              >
                {plan.cta}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
