'use client';
import { useEffect } from 'react';
import { useLang } from '@/context/LangContext';
import Cursor from '@/components/Cursor';
import Loader from '@/components/Loader';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Playground from '@/components/Playground';
import Process from '@/components/Process';
import Pricing from '@/components/Pricing';
import Portfolio from '@/components/Portfolio';
import Testimonials from '@/components/Testimonials';
import ContactAndFooter from '@/components/ContactAndFooter';
import ScrollReveal from '@/components/ScrollReveal';

export default function Home() {
  const { lang, dir } = useLang();

  // Sync html lang & dir with language state
  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir = dir;
  }, [lang, dir]);

  return (
    <>
      <Cursor />
      <Loader />
      <Navbar />
      <main>
        <Hero />
        <About />
        <Playground />
        <Process />
        <Pricing />
        <Portfolio />
        <Testimonials />
        <ContactAndFooter />
      </main>
      <ScrollReveal />
    </>
  );
}
